#!/bin/bash

# Check if the number of arguments is exactly 1
if [ "$#" -ne 1 ]; then 
    echo "Usage: $0 <number_of_rows>" 
    exit 1
fi 

rows=$1

# Loop to print the reversed triangle of numbers
for ((i = rows; i >= 1; i--)); do 
    for ((j = 1; j <= i; j++)); do 
        echo -n "$j "
    done 
    echo ""
done
