run_test() {
    expected_output="$1" 
    input="$2"

    output=$(./63.sh "$input" | tr -d '\r')

    if [ "$output" == "$expected_output" ]; then 
        echo "Test passed for input $input."
    else 
        echo "Test failed for input $input." 
        echo "Expected:" 
        echo "$expected_output" 
        echo "Got:" 
        echo "$output"
    fi 
}

run_test "$(printf "1 \n")" 1 
run_test "$(printf "1 2 \n1 \n")" 2 
run_test "$(printf "1 2 3 \n1 2 \n1 \n")" 3 
run_test "$(printf "1 2 3 4 \n1 2 3 \n1 2 \n1 \n")" 4 

