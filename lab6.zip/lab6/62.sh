run_test() {
    expected_output="$1" 
    input="$2" 
    # Capture the output of the star_pattern script 
    output=$(./61.sh "$input") 
    # Compare output with expected output 
    if [ "$output" == "$expected_output" ]; then 
        echo "Test passed for input $input."
    else 
        echo "Test failed for input $input." 
        echo "Expected:" 
        echo "$expected_output" 
        echo "Got:" 
        echo "$output"
    fi 
}
# Test cases
run_test "$(printf "* \n")" 1 
run_test "$(printf "* \n* * \n")" 2 
run_test "$(printf "* \n* * \n* * * \n")" 3 
run_test "$(printf "* \n* * \n* * * \n* * * * \n")" 4

#New test cases
run_test "$(printf "* \n* * \n* * * \n* * * * \n* * * * * \n")" 5
run_test "$(printf "* \n* * \n* * * \n* * * * \n* * * * * \n* * * * * * \n")" 6
run_test "$(printf "* \n* * \n* * * \n* * * * \n* * * * * \n* * * * * * \n* * * * * * * \n")" 7

#Failed test case
run_test "$(printf "* \n* * \n* * * \n* * * * \n* * * * * \n* * * * * * \n* * * * * * * \n* * * * * * * \n")" 8
# Additional tests can be added as needed