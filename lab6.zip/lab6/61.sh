if [ "$#" -ne 1 ]; then 
    echo "Usage: $0 <number_of_rows>" 
    exit 1
fi 
rows=$1 
for ((i = 1; i <= rows; i++)); do 
    for ((j = 1; j <= i; j++)); do 
        echo -n "* "
    done 
    echo ""
done