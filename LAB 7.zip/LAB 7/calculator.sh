#!/bin/bash

# Basic calculator using switch case

echo "Enter first number: "
read num1

echo "Enter second number: "
read num2

echo "Enter operation (+, -, *, /): "
read operation

case $operation in
  +)
    result=$((num1 + num2))
    echo "Result: $result"
    ;;
  -)
    result=$((num1 - num2))
    echo "Result: $result"
    ;;
  \*)
    result=$((num1 * num2))
    echo "Result: $result"
    ;;
  /)
    if [ $num2 -eq 0 ]; then
      echo "Error: Division by zero"
    else
      result=$((num1 / num2))
      echo "Result: $result"
    fi
    ;;
  *)
    echo "Invalid operation!"
    ;;
esac
