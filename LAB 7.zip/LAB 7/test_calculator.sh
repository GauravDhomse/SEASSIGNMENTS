#!/bin/bash

# Function to test the calculator
function test_calculator {
  expected=$1
  input1=$2
  input2=$3
  operator=$4

  # Simulate user input
  result=$(echo -e "$input1\n$input2\n$operator" | ./calculator.sh)

  # Extract the actual result from the calculator script output
  actual=$(echo "$result" | grep "Result:" | awk '{print $2}')
  if [ "$expected" == "$actual" ]; then
    echo "Test passed: $input1 $operator $input2 = $expected"
  else
    echo "Test failed: $input1 $operator $input2. Expected: $expected, Got: $actual"
  fi
}

# Run test cases
echo "Running conformance tests..."

# Test case 1: Addition
test_calculator 5 2 3 "+"

# Test case 2: Subtraction
test_calculator 1 3 2 "-"

# Test case 3: Multiplication
test_calculator 6 2 3 "*"

# Test case 4: Division
test_calculator 2 6 3 "/"

# Test case 5: Division by zero (Expecting error message)
result=$(echo -e "4\n0\n/" | ./calculator.sh)
if [[ $result == *"Error: Division by zero"* ]]; then
  echo "Test passed: Division by zero handled correctly."
else
  echo "Test failed: Division by zero not handled correctly."
fi

# Test case 6: Invalid operator
result=$(echo -e "5\n5\n%" | ./calculator.sh)
if [[ $result == *"Invalid operation!"* ]]; then
  echo "Test passed: Invalid operator handled correctly."
else
  echo "Test failed: Invalid operator not handled correctly."
fi
